#ifndef JL
#define JL

#include "foldalign.hxx"

class jl {

public:

	positionType j;
	positionType l;
	scoreType similarityScore;
	scoreType energyScore;
	stateType state;
	
};

#endif /* JL */
